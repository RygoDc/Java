package Ejercicio1;

public interface GestionableBiblioteca {
    String getNombre();
    String getTipo();

}
